# 谷比算力网站文章管理系统

## 系统概述

本系统允许管理员发布、编辑和删除文章，并自动生成独立的HTML页面和网站地图。

## 常见问题及解决方案

### 1. 404页面未找到错误

如果您遇到"404 - 页面未找到"错误，可能有以下几种原因：

1. **文章页面尚未生成**：发布文章后，系统会自动生成独立的HTML页面。如果页面未生成，请检查：
   - 确保您已成功发布文章
   - 检查浏览器是否阻止了文件下载（查看浏览器下载记录）
   - 查看[new](file://D:\C\gubi\new)目录中是否存在对应的文章页面文件

2. **页面已被删除或移动**：如果您删除了文章，对应的页面文件也需要手动清理

3. **URL输入有误**：请检查URL是否正确，文章页面的格式为`new/article-{ID}.html`

### 2. 启动本地服务器

由于浏览器安全限制，直接打开HTML文件可能会导致一些功能无法正常工作。建议使用本地服务器：

```bash
# 使用Node.js启动服务器（需要安装Node.js）
node server.js

# 然后在浏览器中访问 http://127.0.0.1:3002
```

或者使用Python（如果已安装）：

```bash
# 使用Python 3启动服务器
python -m http.server 3002

# 然后在浏览器中访问 http://127.0.0.1:3002
```

### 3. 后台管理

1. 访问 `http://127.0.0.1:3002/admin.html`
2. 使用默认账号密码登录：
   - 用户名：admin
   - 密码：123456
3. 管理文章：
   - 发布新文章：输入文章标题和内容，点击"发布文章"按钮，系统会自动生成独立的文章页面
   - 编辑文章：在已发布文章列表中点击"编辑"按钮，修改后点击"更新文章"按钮保存更改，系统会更新对应的文章页面
   - 删除文章：在已发布文章列表中点击"删除"按钮，确认后文章将被删除（注意：在本地演示环境中，文章页面文件需要手动清理）

### 4. 文章页面生成

每次发布或更新文章时，系统会自动生成独立的文章页面：

- **开发环境**（localhost或127.0.0.1）：文章页面会通过浏览器下载方式生成，请将下载的文件保存到[new](file://D:\C\gubi\new)目录中
- **生产环境**：文章页面会通过服务器端API自动生成并保存到[new](file://D:\C\gubi\new)目录中

**问题已解决**：之前文章页面通过浏览器下载而不是直接保存到[new](file://D:\C\gubi\new)目录的问题已经修复。现在系统提供了两种处理方式：
1. 在开发环境中，通过浏览器下载方式生成文章页面
2. 在生产环境中，通过服务器端API（`/api/generate-article`）自动生成文章页面并保存到[new](file://D:\C\gubi\new)目录

### 5. 网站地图更新

每次发布、编辑或删除文章时，系统会自动更新根目录下的 `sitemap.xml` 文件。

## 技术实现

- 前端使用 TinyMCE 可视化编辑器（已配置API密钥）
- 文章内容支持富文本格式（图片、链接、标题等）
- 响应式设计，适配各种设备
- 本地存储用于演示，实际部署时应使用数据库

## 安全配置

为了提高系统安全性，TinyMCE已进行以下配置：
- 禁用推广信息和品牌标识
- 限制工具栏功能，只保留必要的编辑功能
- 禁用不必要的菜单项

## 用户体验优化

为了提升文章编写体验，系统已进行以下优化：
- 增加了后台管理页面的宽度（最大宽度从800px增加到1200px）
- 扩大了编辑器区域，提供更大的编写空间
- 优化了表单和列表的样式，使其在大屏幕上更好地展示
- 响应式设计确保在各种设备上都有良好的使用体验
- 添加了文章编辑和删除功能，提供完整的文章管理体验
- 提供取消编辑功能，允许用户在编辑过程中放弃更改
- 修复了表单验证问题，确保表单提交正常工作
- 启用文章页面自动生成，发布文章时会自动创建独立的HTML页面

## 目录结构

```
/
├── index.html          # 网站首页
├── admin.html          # 后台管理页面
├── article.html        # 文章详情页面模板
├── styles.css          # 样式文件
├── server.js           # 本地测试服务器
├── build.js            # 构建脚本（生成文章页面和网站地图）
├── README.md           # 说明文档
├── img/                # 图片资源目录
├── new/                # 文章页面目录
└── sitemap.xml         # 网站地图文件
```

## 注意事项

1. 当前版本使用浏览器本地存储演示功能
2. 实际部署时需要服务器端支持，将文章数据保存到数据库
3. 构建脚本 `build.js` 可用于生成独立的文章页面和网站地图
4. 需要在admin.html中将"YOUR_API_KEY"替换为实际的TinyMCE API密钥
5. 在本地演示环境中，删除文章后对应的文章页面文件需要手动清理
6. 发布文章后，请检查浏览器下载记录，确保文章页面已成功生成
7. 服务器默认运行在端口3002，如需更改请修改server.js文件中的port变量
8. 在开发环境中，文章页面通过浏览器下载生成；在生产环境中，通过服务器端API自动生成
9. 服务器端API端点：`POST /api/generate-article`

# Admin Panel User Management

## Managing Admin Users

User credentials are stored in `users.json` file in the root directory. To enhance security, passwords should be stored as hashes rather than plain text.

### Creating Password Hashes

To generate a password hash, use the provided utility script:

```bash
node generate-hash.js your_password_here
```

The script will output the hash and show you how to structure the entry in the users.json file.

### Example users.json Structure

```json
{
  "users": {
    "admin": {
      "password_hash": "-1593206619",
      "role": "administrator"
    }
  }
}
```

### Legacy Support

For backward compatibility, the system still supports plain text passwords using the `password` field instead of `password_hash`. However, this is not recommended for security reasons.

```json
{
  "users": {
    "admin": {
      "password": "plaintext_password",
      "role": "administrator"
    }
  }
}
```

## Security Notes

1. Always use `password_hash` instead of `password` in production environments
2. Store the users.json file securely and restrict access to it
3. Change default passwords immediately after installation
